package com.example.logging

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import timber.log.Timber
import timber.log.Timber.Forest.plant

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button: Button = findViewById<View>(R.id.button_log) as Button
        button.setOnClickListener {
            val editText: EditText = findViewById<View>(R.id.editTextTextPersonName) as EditText
            Log.v("From EditText", editText.text.toString())
            plant(Timber.DebugTree())
            val button: Button = findViewById<View>(R.id.button_timber) as Button
            button.setOnClickListener {
                val editText: EditText = findViewById<View>(R.id.editTextTextPersonName) as EditText
                Log.v("MainActivity", editText.text.toString())



            }

        }

    }
}